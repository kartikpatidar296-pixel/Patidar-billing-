PATIDAR BILLING — NATIVE FLUTTER SOURCE PROJECT

यह Chrome/PWA पैकेज नहीं है। यह Flutter native app source है, जिससे:
- Android APK/AAB बनाया जा सकता है
- Windows desktop EXE बनाया जा सकता है
- ऐप अपना launcher icon और स्वतंत्र window रख सकता है

इस वातावरण में Flutter SDK/Android build tools उपलब्ध नहीं थे, इसलिए APK/EXE compile या device पर test नहीं किया गया है।

Build करने के लिए Flutter SDK वाला computer:
1. ZIP extract करें
2. flutter create --platforms=android,windows .
3. flutter pub get
4. Android: flutter build apk --release
5. Windows: flutter build windows --release

वर्तमान source एक शुरुआती native UI prototype है। बिल/स्टॉक का स्थायी database, GST calculations, PDF/thermal printing, digital scale integration, login, sync, backup, testing और release signing अभी implement करना बाकी है।
