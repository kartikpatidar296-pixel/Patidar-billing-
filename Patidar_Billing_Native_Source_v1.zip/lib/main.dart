import 'package:flutter/material.dart';

void main() => runApp(const PatidarBillingApp());

const navy = Color(0xFF142D49);
const orange = Color(0xFFFF8A00);
const units = ['पीस', 'फीट (ft)', 'मीटर (m)', 'सेंटीमीटर (cm)', 'मिलीमीटर (mm)', 'मिलीलीटर (ml)', 'किलो', 'लीटर', 'बैग', 'क्विंटल'];

class PatidarBillingApp extends StatelessWidget {
  const PatidarBillingApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Patidar Billing',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: navy), scaffoldBackgroundColor: const Color(0xFFF3F6FA), useMaterial3: true),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final products = <Map<String, dynamic>>[];
  final customer = TextEditingController();
  final productName = TextEditingController();
  final rate = TextEditingController();
  final qty = TextEditingController(text: '1');
  String unit = units.first;
  final cart = <Map<String, dynamic>>[];

  double get subtotal => cart.fold(0, (s, x) => s + (x['qty'] as double) * (x['rate'] as double));

  @override
  void dispose() {
    customer.dispose(); productName.dispose(); rate.dispose(); qty.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [_dashboard(), _billPage(), _stockPage(), _settingsPage()];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: navy, foregroundColor: Colors.white,
        title: Row(children: [
          ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/patidar-logo.png', width: 38, height: 38, fit: BoxFit.cover)),
          const SizedBox(width: 10),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('PATIDAR BILLING', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            Text('Smart Billing • Smart Business', style: TextStyle(fontSize: 11, color: Colors.white70)),
          ])),
        ]),
      ),
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'होम'),
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'बिल'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'स्टॉक'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'सेटिंग'),
        ],
      ),
    );
  }

  Widget _dashboard() => ListView(padding: const EdgeInsets.all(16), children: [
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(18)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('आपका अपना बिजनेस ऐप', style: TextStyle(color: Colors.white70)),
      SizedBox(height: 8), Text('PATIDAR BILLING', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
      Text('Android + Windows • Offline-first design', style: TextStyle(color: Colors.white70)),
    ])),
    const SizedBox(height: 16),
    GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, childAspectRatio: 1.5, crossAxisSpacing: 12, mainAxisSpacing: 12, children: [
      _tile(Icons.add_shopping_cart, 'नया बिल', () => setState(() => tab = 1)),
      _tile(Icons.inventory_2, 'स्टॉक', () => setState(() => tab = 2)),
      _tile(Icons.scale, 'डिजिटल वजन', () => _message('वजन मशीन का मॉडल/कनेक्शन मिलने पर जोड़ा जाएगा।')),
      _tile(Icons.analytics, 'रिपोर्ट', () => _message('बिक्री रिपोर्ट अगले विकास चरण में जोड़ी जाएगी।')),
    ]),
    const SizedBox(height: 12),
    const Text('माप की यूनिट', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
    Wrap(spacing: 8, runSpacing: 8, children: units.map((u) => Chip(label: Text(u))).toList()),
  ]);

  Widget _billPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('नया बिल', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    TextField(controller: customer, decoration: const InputDecoration(labelText: 'ग्राहक का नाम', border: OutlineInputBorder())),
    const SizedBox(height: 12),
    TextField(controller: productName, decoration: const InputDecoration(labelText: 'सामान का नाम', border: OutlineInputBorder())),
    const SizedBox(height: 12),
    DropdownButtonFormField<String>(value: unit, decoration: const InputDecoration(labelText: 'यूनिट', border: OutlineInputBorder()), items: units.map((u) => DropdownMenuItem(value: u, child: Text(u))).toList(), onChanged: (v) => setState(() => unit = v ?? units.first)),
    const SizedBox(height: 12),
    Row(children: [
      Expanded(child: TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'मात्रा', border: OutlineInputBorder()))),
      const SizedBox(width: 10),
      Expanded(child: TextField(controller: rate, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'रेट ₹', border: OutlineInputBorder()))),
    ]),
    const SizedBox(height: 12),
    FilledButton.icon(onPressed: () {
      final q = double.tryParse(qty.text) ?? 0;
      final r = double.tryParse(rate.text) ?? 0;
      if (productName.text.trim().isEmpty || q <= 0 || r < 0) { _message('सामान, मात्रा और सही रेट भरें।'); return; }
      setState(() { cart.add({'name': productName.text.trim(), 'unit': unit, 'qty': q, 'rate': r}); productName.clear(); qty.text = '1'; rate.clear(); });
    }, icon: const Icon(Icons.add), label: const Text('बिल में जोड़ें')),
    const SizedBox(height: 16),
    ...cart.map((x) => Card(child: ListTile(title: Text(x['name']), subtitle: Text('${x['qty']} ${x['unit']} × ₹${x['rate']}'), trailing: Text('₹${(x['qty'] * x['rate']).toStringAsFixed(2)}')))),
    Card(child: ListTile(title: const Text('कुल रकम', style: TextStyle(fontWeight: FontWeight.bold)), trailing: Text('₹${subtotal.toStringAsFixed(2)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)))),
    FilledButton(onPressed: cart.isEmpty ? null : () => _message('यह शुरुआती UI प्रोटोटाइप है। सेविंग, GST और प्रिंटिंग अगले चरण में जोड़ी जाएगी।'), child: const Text('बिल सेव करें (अगला चरण)')),
  ]);

  Widget _stockPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('सामान / स्टॉक', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    TextField(controller: productName, decoration: const InputDecoration(labelText: 'सामान का नाम', border: OutlineInputBorder())),
    const SizedBox(height: 12),
    DropdownButtonFormField<String>(value: unit, decoration: const InputDecoration(labelText: 'यूनिट', border: OutlineInputBorder()), items: units.map((u) => DropdownMenuItem(value: u, child: Text(u))).toList(), onChanged: (v) => setState(() => unit = v ?? units.first)),
    const SizedBox(height: 12),
    TextField(controller: rate, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'बिक्री रेट ₹', border: OutlineInputBorder())),
    const SizedBox(height: 12),
    FilledButton(onPressed: () {
      if (productName.text.trim().isEmpty) { _message('सामान का नाम भरें।'); return; }
      setState(() { products.add({'name': productName.text.trim(), 'unit': unit, 'rate': double.tryParse(rate.text) ?? 0}); productName.clear(); rate.clear(); });
    }, child: const Text('सामान जोड़ें')),
    const SizedBox(height: 12),
    ...products.map((p) => Card(child: ListTile(title: Text(p['name']), subtitle: Text(p['unit']), trailing: Text('₹${(p['rate'] as double).toStringAsFixed(2)}')))),
  ]);

  Widget _settingsPage() => const ListView(padding: EdgeInsets.all(16), children: [
    Text('ऐप सेटिंग', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    SizedBox(height: 12),
    ListTile(leading: Icon(Icons.business), title: Text('Patidar Billing'), subtitle: Text('दुकान का नाम, पता और GSTIN सेटिंग अगले चरण में जोड़ी जाएगी।')),
    ListTile(leading: Icon(Icons.bluetooth), title: Text('वजन मशीन'), subtitle: Text('मॉडल और उपलब्ध पोर्ट के अनुसार Bluetooth / USB / Serial सपोर्ट।')),
    ListTile(leading: Icon(Icons.print), title: Text('प्रिंटर'), subtitle: Text('Bluetooth और USB प्रिंटर सपोर्ट अगले चरण में।')),
    ListTile(leading: Icon(Icons.backup), title: Text('बैकअप'), subtitle: Text('स्थानीय डेटाबेस और सुरक्षित बैकअप अगले चरण में।')),
  ]);

  Widget _tile(IconData icon, String title, VoidCallback onTap) => Card(child: InkWell(borderRadius: BorderRadius.circular(14), onTap: onTap, child: Padding(padding: const EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 30, color: orange), const SizedBox(height: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.w600))]))));

  void _message(String text) => showDialog(context: context, builder: (_) => AlertDialog(content: Text(text), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('ठीक है'))]));
}
